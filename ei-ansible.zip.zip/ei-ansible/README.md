# Evolução Infra Ansible repo

## Basic use
Use the `run.sh` script as a wrapper to ansible-playbook. It will already
specify the correct inventory for the environment, and confirm you're really
sure before running the production playbook. Use like this:
```
./run.sh [ENV] [extra ansible options]
```
Where ENV can be: labs, dev, staging or production;

## Role install
Use the following to install all the dependency roles:
```
./updateRoles.sh
```
Insert new roles in the `requirements.yml` file.

## Ansible Vault
Please, insert the Ansible Vault password in the file `vaultpass` in the root
of this repository, so it can be safely ignored by git. Also, please use only
this passwords for all the encrypted files in our playbooks.
