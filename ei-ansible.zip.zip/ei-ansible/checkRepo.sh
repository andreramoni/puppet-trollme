#!/bin/bash

findList=$( find ./ -type d -name .git )

FS=$'\n'
for git in $findList; do
    repo="$( dirname "$git" )"
    echo "REPO: $repo"
    pushd "$repo" &>/dev/null
    git status
    popd &>/dev/null
    echo ""
done
