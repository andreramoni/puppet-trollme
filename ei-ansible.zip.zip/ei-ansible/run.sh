#!/bin/bash
rolesFolder="roles"

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
rolesPath="$dir/$rolesFolder"

red=`tput setaf 1`
green=`tput setaf 2`
yellow=`tput setaf 3`
normal=`tput sgr0`

function printErr() {
    (>&2 echo -e "${red}$@${normal}")
}

function printWarn() {
    (>&2 echo -e "${yellow}$@${normal}")
}

function confirm() {
    while true; do
        printWarn "Continue? (y/n) "
        read response
        case $response in
            y|Y|s|S)
                printWarn "Continuing..."
                break
                ;;
            *)
                printErr "Aborting..."
                exit 1
                ;;
        esac
    done
}

case "$1" in
    labs)
        printWarn "Environment: LABS"
        env=labs
        ;;
    dev)
        printWarn "Environment: DEV"
        env=dev
        ;;
    stage|staging)
        printWarn "Environment: STAGING"
        env=staging
        ;;
    production)
        printWarn "Are you FUCKING sure you want to run this in ${red}PRODUCTION??"
        confirm
        printWarn "Environment: PRODUCTION"
        env=production
        ;;
    *)
        printErr "Invalid environment."
        exit 1
esac

if [ -f vaultpass ]; then
    vault="--vault-password-file=vaultpass"
fi

opts=${@##$env}
ANSIBLE_ROLES_PATH=$rolesPath ansible-playbook \
    -i inventories/$env/inventory.ini \
    $vault $env.yml $opts
