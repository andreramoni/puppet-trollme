#!/bin/bash
fileName="requirements.yml"
rolesFolder="roles"
dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
rolesPath="$dir/$rolesFolder"

green=`tput setaf 2`
yellow=`tput setaf 3`
normal=`tput sgr0`

mkdir -p "$rolesPath"


entryCount=$( cat "$fileName" | awk 'BEGIN {RS="xxxxx"; FS="- "} {print NF}' )

for entry in `seq 2 $entryCount`; do
    cd $dir
    entry=`cat $fileName |
        awk -v count=$entry 'BEGIN {RS="xxxxx";FS="- "}{print $count}'`
    scm="$(echo $entry | grep -Po '\s*scm:\s*\K(\S*)' )"
    name="$(echo $entry | grep -Po '\s*name:\s*\K(\S*)' )"
    src="$(echo $entry | grep -Po '\s*src:\s*\K(\S*)' )"
    public="$(echo $entry | grep -Po '\s*public:\s*\K(\S*)' )"

    if [ "$scm" != "git" ]; then
        echo -e "${yellow}Module $name isn't a git repository.${normal}"
        continue
    fi

    if [ -d "$rolesPath/$name/.git" ]; then
        echo -e "${green}Updating $name...${normal}"
        cd "$rolesPath/$name"
        git pull
    else
        echo -e "${green}Cloning $name...${normal}"
        if [ "$1" == "public" ]; then
            git clone "$public" "$rolesPath/$name"
        else
            git clone "$src" "$rolesPath/$name"
        fi
    fi
done
